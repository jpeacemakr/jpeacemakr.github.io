/*****************************************************************
*       types.h - simplified for CPSC405 Lab by Gusty Cooper, University of Mary Washington
*       adapted from MIT xv6 by Zhiyi Huang, hzy@cs.otago.ac.nz, University of Otago
********************************************************************/

typedef unsigned int   uint;
typedef unsigned short ushort;
typedef unsigned char  uchar;
